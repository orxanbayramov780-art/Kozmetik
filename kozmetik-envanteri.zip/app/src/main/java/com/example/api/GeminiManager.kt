package com.example.api

import android.util.Log
import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GeminiCosmeticResponse(
    val brand: String,
    val name: String,
    val category: String, // "Cilt Bakımı", "Makyaj", "Saç Bakımı", "Parfüm", "Diğer"
    val paoMonths: Int,
    val usageGuide: String,
    val safetyWarnings: String,
    val description: String
)

object GeminiManager {
    private const val TAG = "GeminiManager"
    private const val MODEL = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"

    private val client = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(45, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    /**
     * Searches for a product globally in the world using Gemini API and parses it
     * into structured data.
     */
    suspend fun searchCosmeticProduct(productQuery: String): GeminiCosmeticResponse? {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.e(TAG, "Gemini API key is not configured correctly.")
            return null
        }

        val prompt = """
            Sana bir kozmetik ürünü adı, markası veya araması verilecek: "$productQuery".
            Lütfen bu ürünü dünyadaki kozmetik veri tabanından tanımla. Ürünün doğrulanmış adını, markasını, kategorisini ("Cilt Bakımı", "Makyaj", "Saç Bakımı", "Parfüm" veya "Diğer" seçeneklerinden tam olarak biri), açıldıktan sonraki kullanım süresini (PAO - ay cinsinden tam sayı, örn: 6, 12, 24 veya belirlenemiyorsa 12), Türkçe kullanım talimatını, Türkçe güvenlik uyarılarını (varsa başka hangi etken maddelerle beraber kullanılmamalı, retinol asit uyuşmazlığı vb.) ve kısa bir tanıtıcı açıklamayı bul.
            
            Sen bir JSON oluşturmalı ve SADECE bu JSON objesini cevap olarak dönmelisin. Ekstra açıklama, markdown veya kod bloğu yazma.
            JSON formatı şu şekilde olmalıdır ve anahtarlar birebir aynı olmalıdır:
            {
               "brand": "Marka Adı",
               "name": "Ürün Tam Adı / Serisi",
               "category": "Cilt Bakımı",
               "pao_months": 12,
               "usage_guide": "Günde 1 kez akşam temizlenmiş cilde dairesel hareketlerle uygulayın. Durulamayın.",
               "safety_warnings": "Retinol içerdiğinden C vitamini veya AHA/BHA asitleriyle aynı rutinde kullanmayın. Gündüz güneş kremi ihmal edilmemelidir.",
               "description": "Kırışıklık karşıtı ve cilt yenileyici gece bakım serumudur."
            }
        """.trimIndent()

        // Construct standard REST generateContent payload using JSONObject
        val partObj = JSONObject().put("text", prompt)
        val partsArray = JSONArray().put(partObj)
        val contentObj = JSONObject().put("parts", partsArray)
        val contentsArray = JSONArray().put(contentObj)

        val configObj = JSONObject()
            .put("responseMimeType", "application/json")
            .put("temperature", 0.2)

        val requestPayload = JSONObject()
            .put("contents", contentsArray)
            .put("generationConfig", configObj)

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = requestPayload.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url("$BASE_URL/$MODEL:generateContent?key=$apiKey")
            .post(requestBody)
            .build()

        try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "API call failed code: ${response.code}, message: ${response.message}")
                    return null
                }

                val bodyStr = response.body?.string() ?: return null
                Log.d(TAG, "Response template: $bodyStr")

                val responseJson = JSONObject(bodyStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            val firstPart = parts.getJSONObject(0)
                            val textResult = firstPart.optString("text")
                            if (!textResult.isNullOrEmpty()) {
                                // Parse the returned JSON text block from Gemini
                                val cleanJson = textResult.trim()
                                Log.d(TAG, "Trimmed JSON: $cleanJson")
                                val jsonParsed = JSONObject(cleanJson)

                                val brand = jsonParsed.optString("brand", "Bilinmeyen Marka")
                                val name = jsonParsed.optString("name", "Bilinmeyen Ürün")
                                val category = jsonParsed.optString("category", "Diğer")
                                val paoMonths = jsonParsed.optInt("pao_months", 12)
                                val usageGuide = jsonParsed.optString("usage_guide", "Kullanım açıklaması bulunamadı.")
                                val safetyWarnings = jsonParsed.optString("safety_warnings", "Geniş güvenlik uyarısı bulunmamaktadır.")
                                val description = jsonParsed.optString("description", "Ürün açıklaması bulunmamaktadır.")

                                return GeminiCosmeticResponse(
                                    brand = brand,
                                    name = name,
                                    category = category,
                                    paoMonths = paoMonths,
                                    usageGuide = usageGuide,
                                    safetyWarnings = safetyWarnings,
                                    description = description
                                )
                            }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing Gemini search API", e)
        }

        return null
    }

    /**
     * Quick assistant query to inspect/analyze custom cosmetic ingredients or custom questions
     * about cosmetics routine.
     */
    suspend fun getRoutineAssistantAdvice(routineSummary: String): String? {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") return null

        val prompt = """
            Sana kullanıcının şu anki kozmetik envanteri ve günlük rutin planı veriliyor:
            $routineSummary
            
            Lütfen bu rutin bilgilerini dermatolojik ve kozmetolojik açıdan analiz et.
            Sorulara yanıt ver:
            1. Ürünlerin kullanım uyumluluğu mükemmel mi yoksa çakışan aktif maddeler var mı? (Örn: Salisilik Asit ile Glikolik Asit çakışması veya Retinol ile soyucu asitlerin çakışması).
            2. Doğru sıralamayla mı uygulanıyorlar? (Önce serum, sonra krem, vb.).
            3. Herhangi bir eksiklik var mı (Örn: Sabah güneş kremi kullanılmaması).
            
            Kullanıcıya samimi, motive edici, çok profesyonel ve kısa (maksimum 3-4 paragraf) bir Türkçe tavsiye rehberi hazırla. Bilgilendirici ve eğlenceli emojisler kullanabilirsin.
        """.trimIndent()

        val partObj = JSONObject().put("text", prompt)
        val partsArray = JSONArray().put(partObj)
        val contentObj = JSONObject().put("parts", partsArray)
        val contentsArray = JSONArray().put(contentObj)

        val requestPayload = JSONObject()
            .put("contents", contentsArray)

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = requestPayload.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url("$BASE_URL/$MODEL:generateContent?key=$apiKey")
            .post(requestBody)
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyStr = response.body?.string() ?: return null
                val responseJson = JSONObject(bodyStr)
                responseJson.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking routine assistant advice", e)
            null
        }
    }

    /**
     * AI Cosmetics Discount & Coupon Suggester.
     * Searches for active cosmetics store deals, discounts, or coupon code structures in Turkey & globally.
     */
    suspend fun getDiscountsAndCoupons(storeOrBrand: String): String? {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") return null

        val prompt = """
            Sana bir kozmetik mağazası veya kozmetik markası sorgusu verilecek: "$storeOrBrand".
            Lütfen bu mağazaya/markaya ait (örn: Sephora, Gratis, Watsons, Rossmann, Trendyol vs.) olası en güncel indirimleri, popüler kampanyaları, indirim kodu veya kupon yapılarını ve tasarruf ipuçlarını topla.
            Kullanıcıya bunlarla ilgili şık, düzenli, Türkçe bir özet hazırla.
            Ayrıca cevabının en son porsiyonunda kopyalanabilir/indirilebilir şık bir "İndirim Kuponu" şablonu oluştur.
            Şablonun içinde özel kampanya kodu, son geçerlilik tarihi ve kazanılan indirim oranı açıkça bulunmalıdır.
        """.trimIndent()

        val partObj = JSONObject().put("text", prompt)
        val partsArray = JSONArray().put(partObj)
        val contentObj = JSONObject().put("parts", partsArray)
        val contentsArray = JSONArray().put(contentObj)

        val requestPayload = JSONObject()
            .put("contents", contentsArray)

        val mediaType = "application/json; charset=utf-8".toMediaType()
        val requestBody = requestPayload.toString().toRequestBody(mediaType)

        val request = Request.Builder()
            .url("$BASE_URL/$MODEL:generateContent?key=$apiKey")
            .post(requestBody)
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyStr = response.body?.string() ?: return null
                val responseJson = JSONObject(bodyStr)
                responseJson.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error seeking discounts and coupons advice", e)
            null
        }
    }
}
