package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cosmetics Brand Palette: Soft Peach, Dusty Rose, Sage Green, Elegant Slate and Warm Sand
val PeachPrimary = Color(0xFFC77DFF) // Vibrant Amethyst / Violet or Rose gold: Let's use Warm Rose Gold/Terracotta:
val Terracotta = Color(0xFFB56576)
val SoftRose = Color(0xFFE5989B)
val LightPeach = Color(0xFFFFB5A7)
val SoftIvory = Color(0xFFFFF1E6)
val SageGreen = Color(0xFF6D9F71)
val WarmSand = Color(0xFFF4F1DE)
val DarkCharcoal = Color(0xFF22223B)
val LightLilac = Color(0xFFF2E9E4)

// Light Palette Colors
val PrimaryLight = Color(0xFFB56576)      // Crimson Rose
val SecondaryLight = Color(0xFF6D9F71)    // Soothing Clean Organics
val TertiaryLight = Color(0xFF9E829C)     // Muted Plum
val BackgroundLight = Color(0xFFFFF9F5)   // Cozy Warm White
val SurfaceLight = Color(0xFFFFFFFF)      // Pure White Detail Card

// Dark Palette Colors (for Cozy Night routine style)
val PrimaryDark = Color(0xFFFFB5A7)       // Radiant Soft Pink
val SecondaryDark = Color(0xFF86B089)     // Phosphorescent Herb
val TertiaryDark = Color(0xFFD4A5B8)      // Lavender Rose
val BackgroundDark = Color(0xFF1B1B1F)    // Midnight Space
val SurfaceDark = Color(0xFF2A2A30)       // Dark Card Slate
