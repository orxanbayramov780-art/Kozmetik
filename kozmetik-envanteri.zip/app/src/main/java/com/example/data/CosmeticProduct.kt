package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cosmetic_products")
data class CosmeticProduct(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val brand: String,
    val name: String,
    val category: String, // e.g., "Cilt Bakımı", "Makyaj", "Saç Bakımı", "Parfüm"
    val expirationDate: Long? = null, // Epoch millisecond representing SKT (Expiration Date)
    val isOpened: Boolean = false,
    val openingDate: Long? = null, // Epoch millisecond of when details were opened
    val paoMonths: Int? = null, // Period After Opening in months (e.g. 6, 12)
    val usageInstructions: String? = null, // Usage instructions or guidelines
    val warningNotes: String? = null, // Warning notes, e.g. "Güneş kremiyle kullanın" or "Retinol ile karıştırmayın"
    val isMorningRoutine: Boolean = false,
    val isNightRoutine: Boolean = false,
    val lastUsedMorningTimestamp: Long = 0L, // To check off daily routine
    val lastUsedNightTimestamp: Long = 0L, // To check off daily routine
    val rating: Int = 0, // 0 to 5 stars
    val notes: String? = null,
    val customImageUri: String? = null // For user uploading or selecting an image
) {
    /**
     * Calculates the remaining shelf-life days based on either the hard Expiry date (SKT)
     * OR the Period After Opening (PAO) from activation.
     * Returns a status wrapper containing remaining days and color state.
     */
    fun getExpirationStatus(currentTimeMs: Long = System.currentTimeMillis()): ExpirationStatus {
        var minRemainingDays = Int.MAX_VALUE
        var hasExpiry = false

        // Check hard Expiration Date
        if (expirationDate != null) {
            val daysLeftHex = ((expirationDate - currentTimeMs) / (1000 * 60 * 60 * 24)).toInt()
            minRemainingDays = daysLeftHex
            hasExpiry = true
        }

        // Check PAO Date (opening date + PAO months)
        if (isOpened && openingDate != null && paoMonths != null) {
            // Calculate limit
            val calendar = java.util.Calendar.getInstance()
            calendar.timeInMillis = openingDate
            calendar.add(java.util.Calendar.MONTH, paoMonths)
            val paoLimitMs = calendar.timeInMillis
            val daysLeftPao = ((paoLimitMs - currentTimeMs) / (1000 * 60 * 60 * 24)).toInt()
            if (daysLeftPao < minRemainingDays) {
                minRemainingDays = daysLeftPao
                hasExpiry = true
            }
        }

        if (!hasExpiry) {
            return ExpirationStatus.NoLimit
        }

        return when {
            minRemainingDays < 0 -> ExpirationStatus.Expired(Math.abs(minRemainingDays))
            minRemainingDays <= 30 -> ExpirationStatus.ExpiringSoon(minRemainingDays)
            else -> ExpirationStatus.Safe(minRemainingDays)
        }
    }
}

sealed class ExpirationStatus {
    object NoLimit : ExpirationStatus()
    data class Safe(val daysLeft: Int) : ExpirationStatus()
    data class ExpiringSoon(val daysLeft: Int) : ExpirationStatus()
    data class Expired(val daysAgo: Int) : ExpirationStatus()
}
