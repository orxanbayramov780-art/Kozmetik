package com.example.data

import kotlinx.coroutines.flow.Flow

class CosmeticRepository(private val cosmeticDao: CosmeticDao) {
    val allProducts: Flow<List<CosmeticProduct>> = cosmeticDao.getAllProducts()
    val morningProducts: Flow<List<CosmeticProduct>> = cosmeticDao.getMorningRoutineProducts()
    val nightProducts: Flow<List<CosmeticProduct>> = cosmeticDao.getNightRoutineProducts()

    suspend fun getProductById(id: Int): CosmeticProduct? {
        return cosmeticDao.getProductById(id)
    }

    suspend fun insertProduct(product: CosmeticProduct): Long {
        return cosmeticDao.insertProduct(product)
    }

    suspend fun updateProduct(product: CosmeticProduct) {
        return cosmeticDao.updateProduct(product)
    }

    suspend fun deleteProduct(product: CosmeticProduct) {
        return cosmeticDao.deleteProduct(product)
    }

    suspend fun deleteProductById(id: Int) {
        return cosmeticDao.deleteProductById(id)
    }
}
