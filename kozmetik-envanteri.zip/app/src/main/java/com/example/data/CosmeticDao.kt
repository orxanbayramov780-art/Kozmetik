package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CosmeticDao {
    @Query("SELECT * FROM cosmetic_products ORDER BY id DESC")
    fun getAllProducts(): Flow<List<CosmeticProduct>>

    @Query("SELECT * FROM cosmetic_products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: Int): CosmeticProduct?

    @Query("SELECT * FROM cosmetic_products WHERE isMorningRoutine = 1")
    fun getMorningRoutineProducts(): Flow<List<CosmeticProduct>>

    @Query("SELECT * FROM cosmetic_products WHERE isNightRoutine = 1")
    fun getNightRoutineProducts(): Flow<List<CosmeticProduct>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: CosmeticProduct): Long

    @Update
    suspend fun updateProduct(product: CosmeticProduct)

    @Delete
    suspend fun deleteProduct(product: CosmeticProduct)

    @Query("DELETE FROM cosmetic_products WHERE id = :id")
    suspend fun deleteProductById(id: Int)
}
