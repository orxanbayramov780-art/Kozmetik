package com.example.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.api.GeminiCosmeticResponse
import com.example.api.GeminiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CosmeticViewModel(private val repository: CosmeticRepository) : ViewModel() {

    // --- Database State Sources ---
    val allProducts: StateFlow<List<CosmeticProduct>> = repository.allProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val morningProducts: StateFlow<List<CosmeticProduct>> = repository.morningProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val nightProducts: StateFlow<List<CosmeticProduct>> = repository.nightProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Gemini Search State ---
    private val _searchResult = MutableStateFlow<GeminiCosmeticResponse?>(null)
    val searchResult: StateFlow<GeminiCosmeticResponse?> = _searchResult.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    private val _searchError = MutableStateFlow<String?>(null)
    val searchError: StateFlow<String?> = _searchError.asStateFlow()

    // --- AI Advisor State ---
    private val _aiAdvice = MutableStateFlow<String?>(null)
    val aiAdvice: StateFlow<String?> = _aiAdvice.asStateFlow()

    private val _isLoadingAdvice = MutableStateFlow(false)
    val isLoadingAdvice: StateFlow<Boolean> = _isLoadingAdvice.asStateFlow()

    // --- Gemini Discount Tracker State ---
    private val _dealAdvice = MutableStateFlow<String?>(null)
    val dealAdvice: StateFlow<String?> = _dealAdvice.asStateFlow()

    private val _isLoadingDeals = MutableStateFlow(false)
    val isLoadingDeals: StateFlow<Boolean> = _isLoadingDeals.asStateFlow()

    // --- Actions ---

    fun searchProductGlobally(query: String) {
        if (query.trim().isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            _isSearching.value = true
            _searchError.value = null
            _searchResult.value = null
            try {
                val result = GeminiManager.searchCosmeticProduct(query)
                if (result != null) {
                    _searchResult.value = result
                } else {
                    _searchError.value = "Ürün bulunamadı veya API hatası oluştu. Lütfen Gemini API anahtarınızı Secrets panelinde tanımladığınızdan emin olun."
                }
            } catch (e: Exception) {
                _searchError.value = "Hata oluştu: ${e.localizedMessage}"
            } finally {
                _isSearching.value = false
            }
        }
    }

    fun clearSearchResult() {
        _searchResult.value = null
        _searchError.value = null
    }

    fun queryActiveDiscounts(storeOrBrand: String) {
        if (storeOrBrand.trim().isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingDeals.value = true
            _dealAdvice.value = null
            try {
                val advice = GeminiManager.getDiscountsAndCoupons(storeOrBrand)
                _dealAdvice.value = advice ?: "Seçilen kozmetik markası veya mağazası için indirim analiz bilgisi şu anda alınamadı."
            } catch (e: Exception) {
                _dealAdvice.value = "Hata oluştu: ${e.localizedMessage}"
            } finally {
                _isLoadingDeals.value = false
            }
        }
    }

    fun clearDealsQuery() {
        _dealAdvice.value = null
    }

    fun addSearchedProductToInventory(
        response: GeminiCosmeticResponse,
        expiryDate: Long? = null,
        isOpened: Boolean = false,
        openingDate: Long? = null,
        isMorning: Boolean = false,
        isNight: Boolean = false
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val product = CosmeticProduct(
                brand = response.brand,
                name = response.name,
                category = response.category,
                expirationDate = expiryDate,
                isOpened = isOpened,
                openingDate = if (isOpened) (openingDate ?: System.currentTimeMillis()) else null,
                paoMonths = response.paoMonths,
                usageInstructions = response.usageGuide,
                warningNotes = response.safetyWarnings,
                isMorningRoutine = isMorning,
                isNightRoutine = isNight,
                notes = response.description
            )
            repository.insertProduct(product)
        }
    }

    fun addManualProduct(
        brand: String,
        name: String,
        category: String,
        expiryDate: Long?,
        isOpened: Boolean,
        openingDate: Long?,
        paoMonths: Int?,
        usageInstructions: String?,
        warningNotes: String?,
        isMorning: Boolean,
        isNight: Boolean,
        notes: String?
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val product = CosmeticProduct(
                brand = brand,
                name = name,
                category = category,
                expirationDate = expiryDate,
                isOpened = isOpened,
                openingDate = if (isOpened) (openingDate ?: System.currentTimeMillis()) else null,
                paoMonths = paoMonths,
                usageInstructions = usageInstructions,
                warningNotes = warningNotes,
                isMorningRoutine = isMorning,
                isNightRoutine = isNight,
                notes = notes
            )
            repository.insertProduct(product)
        }
    }

    fun toggleProductOpened(product: CosmeticProduct) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = if (product.isOpened) {
                // If closing, remove fields
                product.copy(isOpened = false, openingDate = null)
            } else {
                // Starting consumption now
                product.copy(isOpened = true, openingDate = System.currentTimeMillis())
            }
            repository.updateProduct(updated)
        }
    }

    fun toggleMorningRoutine(product: CosmeticProduct) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = product.copy(isMorningRoutine = !product.isMorningRoutine)
            repository.updateProduct(updated)
        }
    }

    fun toggleNightRoutine(product: CosmeticProduct) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = product.copy(isNightRoutine = !product.isNightRoutine)
            repository.updateProduct(updated)
        }
    }

    fun checkOffMorningUsage(product: CosmeticProduct) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = product.copy(lastUsedMorningTimestamp = System.currentTimeMillis())
            repository.updateProduct(updated)
        }
    }

    fun checkOffNightUsage(product: CosmeticProduct) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = product.copy(lastUsedNightTimestamp = System.currentTimeMillis())
            repository.updateProduct(updated)
        }
    }

    fun deleteProduct(product: CosmeticProduct) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteProduct(product)
        }
    }

    fun getAIAdvice() {
        viewModelScope.launch(Dispatchers.IO) {
            _isLoadingAdvice.value = true
            _aiAdvice.value = null
            try {
                val list = allProducts.value
                if (list.isEmpty()) {
                    _aiAdvice.value = "Analiz edebilmek için envanterinizde kozmetik ürünleri bulunmalıdır. Ürünlerinizi arama sayfasından veya manuel ekleme formundan kaydedebilirsiniz."
                    return@launch
                }

                val sb = java.lang.StringBuilder()
                sb.append("Envanter listesi: \n")
                list.forEachIndexed { index, product ->
                    sb.append("${index + 1}. [${product.brand}] - ${product.name} (Kategori: ${product.category})\n")
                    sb.append("   - Durum: ${if (product.isOpened) "Açık (Başlama Tarihi: ${formatDate(product.openingDate)}, PAO: ${product.paoMonths} Ay)" else "Kapalı"}\n")
                    sb.append("   - Rutinler: ${if (product.isMorningRoutine) "Gündüz (Sabah)" else ""} ${if (product.isNightRoutine) "Gece (Akşam)" else ""}\n")
                    sb.append("   - Talimatlar: ${product.usageInstructions ?: "Yok"}\n")
                    sb.append("   - Güvenlik Uyarıları: ${product.warningNotes ?: "Belirtilmemiş"}\n")
                }

                val advice = GeminiManager.getRoutineAssistantAdvice(sb.toString())
                if (advice != null) {
                    _aiAdvice.value = advice
                } else {
                    _aiAdvice.value = "AI tavsiyeleri şu an alınamıyor, lütfen bağlantınızı kontrol edip tekrar deneyin."
                }
            } catch (e: Exception) {
                _aiAdvice.value = "Dermatolojik analiz esnasında hata oluştu: ${e.localizedMessage}"
            } finally {
                _isLoadingAdvice.value = false
            }
        }
    }

    private fun formatDate(timestamp: Long?): String {
        if (timestamp == null) return "N/A"
        val df = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
        return df.format(java.util.Date(timestamp))
    }
}

class CosmeticViewModelFactory(private val repository: CosmeticRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CosmeticViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CosmeticViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
