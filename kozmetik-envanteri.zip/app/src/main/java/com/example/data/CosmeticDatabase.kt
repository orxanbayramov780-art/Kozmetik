package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [CosmeticProduct::class], version = 1, exportSchema = false)
abstract class CosmeticDatabase : RoomDatabase() {
    abstract val cosmeticDao: CosmeticDao

    companion object {
        @Volatile
        private var INSTANCE: CosmeticDatabase? = null

        fun getDatabase(context: Context): CosmeticDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CosmeticDatabase::class.java,
                    "cosmetics_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
