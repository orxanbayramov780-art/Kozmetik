package com.example

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.api.GeminiCosmeticResponse
import com.example.data.*
import com.example.ui.theme.MyApplicationTheme
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Obtain repository and db
                val context = LocalContext.current
                val database = remember { CosmeticDatabase.getDatabase(context) }
                val repository = remember { CosmeticRepository(database.cosmeticDao) }
                val cosmeticViewModel: CosmeticViewModel = viewModel(
                    factory = CosmeticViewModelFactory(repository)
                )

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainCosmeticsApp(viewModel = cosmeticViewModel)
                }
            }
        }
    }
}

@Composable
fun MainCosmeticsApp(viewModel: CosmeticViewModel) {
    // Tab state: 0 = Envanterim (Inventory), 1 = AI Bilgi & Arama (Global Lookup), 2 = Rutinlerim (Routines), 3 = İndirimler (Deals)
    var activeTab by remember { mutableStateOf(0) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    icon = { Icon(Icons.Default.List, contentDescription = "Envanterim") },
                    label = { Text("Envanterim", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("nav_inventory_tab")
                )
                NavigationBarItem(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Küresel Arama") },
                    label = { Text("AI Arama", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("nav_search_tab")
                )
                NavigationBarItem(
                    selected = activeTab == 2,
                    onClick = { activeTab = 2 },
                    icon = { Icon(Icons.Default.Face, contentDescription = "Rutinler ve AI") },
                    label = { Text("Rutin", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("nav_routines_tab")
                )
                NavigationBarItem(
                    selected = activeTab == 3,
                    onClick = { activeTab = 3 },
                    icon = { Icon(Icons.Default.ShoppingCart, contentDescription = "İndirimler & Kampanyalar") },
                    label = { Text("İndirimler", fontWeight = FontWeight.SemiBold) },
                    modifier = Modifier.testTag("nav_discounts_tab")
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // App Global Header
            HeaderBlock()

            // Dynamic Tab Views
            Crossfade(targetState = activeTab, label = "TabTransition") { tab ->
                when (tab) {
                    0 -> InventoryView(viewModel = viewModel)
                    1 -> GlobalSearchView(viewModel = viewModel)
                    2 -> RoutinesView(viewModel = viewModel)
                    3 -> DiscountsView(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun HeaderBlock() {
    val gradient = Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.primary,
            MaterialTheme.colorScheme.tertiary
        )
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(gradient)
            .padding(horizontal = 20.dp, vertical = 20.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Face,
                    contentDescription = "Cosmetics App Logo",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(28.dp)
                )
                Text(
                    text = "Kozmetik Envanteri",
                    fontSize = 22.sp,
                    color = MaterialTheme.colorScheme.onPrimary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "Cildiniz için bilinçli, güvenli ve taze kozmetik takibi",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f)
            )
        }
    }
}

// ==================== TAB 0: INVENTORY VIEW ====================

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun InventoryView(viewModel: CosmeticViewModel) {
    val products by viewModel.allProducts.collectAsState()
    var selectedCategoryFilter by remember { mutableStateOf("Hepsi") }
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedProductForDetail by remember { mutableStateOf<CosmeticProduct?>(null) }

    val categories = listOf("Hepsi", "Cilt Bakımı", "Makyaj", "Saç Bakımı", "Parfüm", "Diğer")

    // Expired / Expiring statistics for Reminders
    val currentTime = System.currentTimeMillis()
    val expiredCount = products.count {
        it.getExpirationStatus(currentTime) is ExpirationStatus.Expired
    }
    val expiringCount = products.count {
        it.getExpirationStatus(currentTime) is ExpirationStatus.ExpiringSoon
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // Reminders / Expiration Warnings Segment
            if (expiredCount > 0 || expiringCount > 0) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.75f)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Uyarı",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Akıllı Sağlık Hatırlatıcısı",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            val warningText = StringBuilder()
                            if (expiredCount > 0) warningText.append("$expiredCount ürününüzün süresi dolmuş!")
                            if (expiringCount > 0) {
                                if (warningText.isNotEmpty()) warningText.append(" ")
                                warningText.append("$expiringCount ürününüzün süresi dolmak üzere.")
                            }
                            Text(
                                text = warningText.toString(),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.9f)
                            )
                        }
                    }
                }
            }

            // Category Chips Selection Banner
            Text(
                text = "Kozmetikleriniz",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // LazyRow is avoided for simplicity and standard safe horizontal layout wrapping if tiny,
                // but standard Row with scroll is clean. We can implement standard Row wrapped in a Scroll state or just a grid.
                // Scrollable Row:
                Box(modifier = Modifier.fillMaxWidth()) {
                    androidx.compose.foundation.lazy.LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(categories) { cat ->
                            val isSelected = cat == selectedCategoryFilter
                            InputChip(
                                selected = isSelected,
                                onClick = { selectedCategoryFilter = cat },
                                label = { Text(cat, fontSize = 12.sp) },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                                )
                            )
                        }
                    }
                }
            }

            // Products list
            val filteredProducts = if (selectedCategoryFilter == "Hepsi") {
                products
            } else {
                products.filter { it.category == selectedCategoryFilter }
            }

            if (filteredProducts.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Face,
                        contentDescription = "Envanter Boş",
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Henüz ürün eklenmemiş.",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Aradığınız ürünleri bulmak için 'AI Arama' sekmesine geçebilir veya sağ alttaki '+' butonu ile manuel ekleyebilirsiniz.",
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredProducts, key = { it.id }) { item ->
                        InventoryProductCard(
                            product = item,
                            currentTime = currentTime,
                            onClick = { selectedProductForDetail = item },
                            onDelete = { viewModel.deleteProduct(item) },
                            onToggleOpened = { viewModel.toggleProductOpened(item) }
                        )
                    }
                }
            }
        }

        // Floating Action Button + (Add Custom Product)
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("add_product_fab"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        ) {
            Icon(Icons.Default.Add, contentDescription = "Manuel Ürün Ekle")
        }
    }

    // Modal Add Dialog
    if (showAddDialog) {
        AddManualProductDialog(
            onDismiss = { showAddDialog = false },
            onSave = { brand, name, cat, exp, opened, openedDate, pao, usage, warning, morning, night, notes ->
                viewModel.addManualProduct(
                    brand = brand,
                    name = name,
                    category = cat,
                    expiryDate = exp,
                    isOpened = opened,
                    openingDate = openedDate,
                    paoMonths = pao,
                    usageInstructions = usage,
                    warningNotes = warning,
                    isMorning = morning,
                    isNight = night,
                    notes = notes
                )
                showAddDialog = false
            }
        )
    }

    // Modal Detail Dialogue
    if (selectedProductForDetail != null) {
        ProductDetailDialog(
            product = selectedProductForDetail!!,
            currentTime = currentTime,
            onDismiss = { selectedProductForDetail = null },
            onToggleOpened = { viewModel.toggleProductOpened(selectedProductForDetail!!) },
            onToggleMorning = { viewModel.toggleMorningRoutine(selectedProductForDetail!!) },
            onToggleNight = { viewModel.toggleNightRoutine(selectedProductForDetail!!) },
            onDelete = {
                viewModel.deleteProduct(selectedProductForDetail!!)
                selectedProductForDetail = null
            }
        )
    }
}

@Composable
fun InventoryProductCard(
    product: CosmeticProduct,
    currentTime: Long,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    onToggleOpened: () -> Unit
) {
    val expiryStatus = product.getExpirationStatus(currentTime)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("product_card_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                // Category Tag
                Text(
                    text = product.category.uppercase(Locale.getDefault()),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(2.dp))
                // Brand Name
                Text(
                    text = product.brand,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
                // Product Name
                Text(
                    text = product.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Expiry and opened details
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    when (expiryStatus) {
                        is ExpirationStatus.NoLimit -> {
                            BadgeIndicator(text = "Süre Sınırı Yok", containerColor = Color(0xFFE2E2E2), textColor = Color(0xFF555555))
                        }
                        is ExpirationStatus.Safe -> {
                            BadgeIndicator(text = "${expiryStatus.daysLeft} Gün Kaldı", containerColor = Color(0xFFE8F5E9), textColor = Color(0xFF2E7D32))
                        }
                        is ExpirationStatus.ExpiringSoon -> {
                            BadgeIndicator(text = "Son 30 Gün! (${expiryStatus.daysLeft} G)", containerColor = Color(0xFFFFF8E1), textColor = Color(0xFFF57F17))
                        }
                        is ExpirationStatus.Expired -> {
                            BadgeIndicator(text = "SÜRESİ GEÇTİ! (${expiryStatus.daysAgo} Gün Önce)", containerColor = Color(0xFFFFEBEE), textColor = Color(0xFFC62828))
                        }
                    }

                    if (product.isOpened) {
                        BadgeIndicator(text = "Açık", containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), textColor = MaterialTheme.colorScheme.primary)
                    } else {
                        BadgeIndicator(text = "Kapak Kapalı", containerColor = Color(0xFFEEF1F6), textColor = Color(0xFF6B7A90))
                    }
                }
            }

            // Expiry Quick Tool Button or Quick state control
            IconButton(onClick = { onToggleOpened() }) {
                Icon(
                    imageVector = if (product.isOpened) Icons.Default.Check else Icons.Default.PlayArrow,
                    contentDescription = if (product.isOpened) "Kapağı kapat" else "Kapağı aç / Kullanmaya Başla",
                    tint = if (product.isOpened) MaterialTheme.colorScheme.primary else Color.Gray,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}

@Composable
fun BadgeIndicator(text: String, containerColor: Color, textColor: Color) {
    Box(
        modifier = Modifier
            .background(containerColor, RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

// ==================== TAB 1: GLOBAL SEARCH VIEW (GEMINI API) ====================

@Composable
fun GlobalSearchView(viewModel: CosmeticViewModel) {
    var searchQuery by remember { mutableStateOf("") }
    val searchResult by viewModel.searchResult.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()
    val errorMsg by viewModel.searchError.collectAsState()

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Text(
                text = "Küresel Kozmetik Arama",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Dünyadaki herhangi bir kozmetik ürününü, etken maddeyi, kullanım kurallarını sorgulayabilir ve anında envanterinize kaydedebilirsiniz.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Search Bar Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Örn: L'Oreal Hyaluronic Acid Serum veya CeraVe") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("global_search_input"),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Arama Simgesi") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Temizle")
                        }
                    }
                },
                singleLine = true
            )

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = { viewModel.searchProductGlobally(searchQuery) },
                enabled = !isSearching && searchQuery.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("global_search_button"),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                if (isSearching) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                } else {
                    Text("Ara ve AI Çözümle", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }

        // Show parsing feedback or error messages
        if (errorMsg != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Default.Warning, contentDescription = "Hata", tint = MaterialTheme.colorScheme.error)
                            Text(text = "Hata", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = errorMsg!!, fontSize = 12.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }

        // Search Result Showcase card with Quick "Add to Inventory" Action
        if (searchResult != null) {
            item {
                Text(
                    text = "Bulunan Ürün Detayı (AI Çözümü)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_result_card"),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Category tag
                        BadgeIndicator(
                            text = searchResult!!.category.uppercase(Locale.getDefault()),
                            containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f),
                            textColor = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(4.dp))

                        // Identification
                        Text(
                            text = searchResult!!.brand,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                        )
                        Text(
                            text = searchResult!!.name,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Descriptions
                        Text(text = "Ürün Özellikleri", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(text = searchResult!!.description, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

                        Spacer(modifier = Modifier.height(10.dp))

                        // Usage guidelines
                        Text(text = "Açıldıktan Sonra Ömür (PAO)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(text = "${searchResult!!.paoMonths} Ay (Önerilen)", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(text = "Kullanım Şekli", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(text = searchResult!!.usageGuide, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)

                        Spacer(modifier = Modifier.height(10.dp))

                        // Safe instructions alert box
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3CD)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Info, contentDescription = "Dikkat", tint = Color(0xFF856404), modifier = Modifier.size(16.dp))
                                    Text("Aktif Madde & Güvenlik Uyarıları", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color(0xFF856404))
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(text = searchResult!!.safetyWarnings, fontSize = 11.sp, color = Color(0xFF856404))
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Action button to Add
                        var pickDateAndAdd by remember { mutableStateOf(false) }
                        var pickedExpiryTime by remember { mutableStateOf<Long?>(null) }
                        var routineMorning by remember { mutableStateOf(false) }
                        var routineNight by remember { mutableStateOf(false) }

                        if (!pickDateAndAdd) {
                            Button(
                                onClick = { pickDateAndAdd = true },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("add_searched_to_inventory_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Envanterime Kaydet")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Envanterime Ekle", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            // Quick details picker
                            Column {
                                Divider(modifier = Modifier.padding(vertical = 10.dp))
                                Text("Ek Tercihler", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(modifier = Modifier.height(6.dp))

                                // Expiration picker click
                                val mCalendar = Calendar.getInstance()
                                val mYear = mCalendar.get(Calendar.YEAR)
                                val mMonth = mCalendar.get(Calendar.MONTH)
                                val mDay = mCalendar.get(Calendar.DAY_OF_MONTH)
                                
                                val datePickerDialog = DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val cal = Calendar.getInstance()
                                        cal.set(year, month, dayOfMonth)
                                        pickedExpiryTime = cal.timeInMillis
                                    }, mYear, mMonth, mDay
                                )

                                OutlinedButton(
                                    onClick = { datePickerDialog.show() },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.DateRange, contentDescription = "Tarih")
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (pickedExpiryTime == null) "Son Kullanma Tarihi Seçin (Seçmeli)"
                                        else "SKT: " + SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(pickedExpiryTime!!))
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Register routine placements
                                Text("Rutinlerime yerleştir:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = routineMorning, onCheckedChange = { routineMorning = it })
                                        Text("Sabah Rutini", fontSize = 12.sp)
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(checked = routineNight, onCheckedChange = { routineNight = it })
                                        Text("Akşam Rutini", fontSize = 12.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    TextButton(onClick = { pickDateAndAdd = false }) {
                                        Text("İptal")
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.addSearchedProductToInventory(
                                                response = searchResult!!,
                                                expiryDate = pickedExpiryTime,
                                                isOpened = false,
                                                isMorning = routineMorning,
                                                isNight = routineNight
                                            )
                                            viewModel.clearSearchResult()
                                            searchQuery = ""
                                            pickDateAndAdd = false
                                        },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Tamamla", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== TAB 2: ROUTINES & AI PLANNER VIEW ====================

@Composable
fun RoutinesView(viewModel: CosmeticViewModel) {
    val morningList by viewModel.morningProducts.collectAsState()
    val nightList by viewModel.nightProducts.collectAsState()
    val aiAdvice by viewModel.aiAdvice.collectAsState()
    val isLoadingAdvice by viewModel.isLoadingAdvice.collectAsState()

    val currentTime = System.currentTimeMillis()
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val todayStr = dateFormat.format(Date(currentTime))

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 80.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = "Günlük Bakım Rutinim", fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(
                text = "Kozmetiklerinizin doğru sırayla sürülüp sürülmediğini takip edin ve günlük işaretleyin.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
            Divider(modifier = Modifier.padding(vertical = 10.dp))
        }

        // MORNING ROUTINE
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Home, contentDescription = "Gündüz", tint = Color(0xFFF57F17))
                Text(text = "🌅 Gündüz Rutini", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (morningList.isEmpty()) {
            item {
                Text(
                    text = "Gündüz rutininizde hiç ürün yok. Detaylar penceresinden ürünlerinizi buraya ekleyin.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(start = 28.dp)
                )
            }
        } else {
            items(morningList, key = { "morning_${it.id}" }) { item ->
                val isChecked = dateFormat.format(Date(item.lastUsedMorningTimestamp)) == todayStr
                RoutineItemCheckCard(
                    product = item,
                    isChecked = isChecked,
                    onCheckedChange = { viewModel.checkOffMorningUsage(item) }
                )
            }
        }

        // NIGHT ROUTINE
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Icon(Icons.Default.Info, contentDescription = "Gece", tint = Color(0xFF673AB7))
                Text(text = "🌙 Akşam Rutini", fontSize = 15.sp, fontWeight = FontWeight.Bold)
            }
        }

        if (nightList.isEmpty()) {
            item {
                Text(
                    text = "Gece rutininizde hiç ürün yok. Detaylar penceresinden ürünlerinizi buraya ekleyin.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(start = 28.dp)
                )
            }
        } else {
            items(nightList, key = { "night_${it.id}" }) { item ->
                val isChecked = dateFormat.format(Date(item.lastUsedNightTimestamp)) == todayStr
                RoutineItemCheckCard(
                    product = item,
                    isChecked = isChecked,
                    onCheckedChange = { viewModel.checkOffNightUsage(item) }
                )
            }
        }

        // DERMATOLOGICAL COHESION AUDITOR (AI ASSISTANT)
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("routine_ai_card"),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🩺 AI Dermatolojik Rutin Denetleyicisi",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Eklediğiniz ürünlerin kombine sürülmesinde etken madde uyuşmazlığı, asit uyuşmazlığı gibi tehlikeli durumları Gemini yapay zekası ile denetleyin ve saniyeler içinde rapor alın.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.getAIAdvice() },
                        enabled = !isLoadingAdvice,
                        modifier = Modifier.fillMaxWidth().testTag("get_ai_advice_btn")
                    ) {
                        if (isLoadingAdvice) {
                            CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(20.dp))
                        } else {
                            Text("Rutinimi AI İle Analiz Et", fontWeight = FontWeight.Bold)
                        }
                    }

                    if (aiAdvice != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = aiAdvice!!,
                            fontSize = 12.sp,
                            lineHeight = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RoutineItemCheckCard(
    product: CosmeticProduct,
    isChecked: Boolean,
    onCheckedChange: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isChecked) Color(0xFFE8F5E9) else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange() }
            .padding(start = 28.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.brand,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    text = product.name,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isChecked) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurface
                )
            }

            Checkbox(
                checked = isChecked,
                onCheckedChange = { onCheckedChange() },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF2E7D32))
            )
        }
    }
}

// ==================== SHARED: ADD MANUAL PRODUCT FORM OVERLAY ====================

@Composable
fun AddManualProductDialog(
    onDismiss: () -> Unit,
    onSave: (
        brand: String, name: String, category: String, expiryDate: Long?,
        isOpened: Boolean, openingDate: Long?, paoMonths: Int?,
        usageInstructions: String?, warningNotes: String?,
        isMorning: Boolean, isNight: Boolean, notes: String?
    ) -> Unit
) {
    var brand by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Cilt Bakımı") }
    var isOpened by remember { mutableStateOf(false) }
    var paoMonths by remember { mutableStateOf("12") }
    var usageInstructions by remember { mutableStateOf("") }
    var warningNotes by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var isMorning by remember { mutableStateOf(false) }
    var isNight by remember { mutableStateOf(false) }

    var pickedExpiryDate by remember { mutableStateOf<Long?>(null) }
    val context = LocalContext.current

    val categories = listOf("Cilt Bakımı", "Makyaj", "Saç Bakımı", "Parfüm", "Diğer")

    Dialog(onDismissRequest = { onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .testTag("add_manual_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Yeni Kozmetik Ürünü Ekle",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.primary
                )

                OutlinedTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = { Text("Marka Adı") },
                    modifier = Modifier.fillMaxWidth().testTag("input_brand"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Ürün Adı") },
                    modifier = Modifier.fillMaxWidth().testTag("input_name"),
                    singleLine = true
                )

                // Category selection chips
                Text("Kategori Seçimi", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Quick wrapping grid
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            categories.take(3).forEach { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = { category = cat },
                                    label = { Text(cat, fontSize = 10.sp) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            categories.drop(3).forEach { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = { category = cat },
                                    label = { Text(cat, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }

                Divider()

                // Expiry Picker
                val calendar = Calendar.getInstance()
                val dateDialog = DatePickerDialog(
                    context,
                    { _, year, month, day ->
                        val selected = Calendar.getInstance()
                        selected.set(year, month, day)
                        pickedExpiryDate = selected.timeInMillis
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Son Kullanma Tarihi (SKT)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(
                            text = if (pickedExpiryDate == null) "Belirlenmedi" else SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(pickedExpiryDate!!)),
                            fontSize = 11.sp
                        )
                    }
                    Button(onClick = { dateDialog.show() }, modifier = Modifier.testTag("pick_skt_btn")) {
                        Text("Seç", fontSize = 11.sp)
                    }
                }

                // PAO Selection
                OutlinedTextField(
                    value = paoMonths,
                    onValueChange = { paoMonths = it },
                    label = { Text("Açıldıktan sonraki ömür (PAO Ay, Örn: 12)") },
                    modifier = Modifier.fillMaxWidth().testTag("input_pao"),
                    singleLine = true
                )

                // Open state checkbox
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = isOpened, onCheckedChange = { isOpened = it })
                    Column {
                        Text("Ürün şu an açık mı?", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Eğer açıksa, süre sayacı bugünden itibaren geri sayacaktır.", fontSize = 10.sp)
                    }
                }

                Divider()

                // Routine choices
                Text("Ürünün bulunacağı rutin:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isMorning, onCheckedChange = { isMorning = it })
                        Text("Sabah", fontSize = 11.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isNight, onCheckedChange = { isNight = it })
                        Text("Akşam", fontSize = 11.sp)
                    }
                }

                OutlinedTextField(
                    value = usageInstructions,
                    onValueChange = { usageInstructions = it },
                    label = { Text("Nasıl kullanılır? (Kullanım Qaydaları)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = warningNotes,
                    onValueChange = { warningNotes = it },
                    label = { Text("Güvenlik Uyarıları ve Madde Uyuşmazlığı") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Kişisel Notlarım") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    TextButton(onClick = { onDismiss() }) {
                        Text("Vazgeç")
                    }
                    Button(
                        onClick = {
                            if (brand.trim().isNotEmpty() && name.trim().isNotEmpty()) {
                                onSave(
                                    brand, name, category, pickedExpiryDate,
                                    isOpened, if (isOpened) System.currentTimeMillis() else null,
                                    paoMonths.toIntOrNull() ?: 12,
                                    usageInstructions, warningNotes,
                                    isMorning, isNight, notes
                                )
                            }
                        },
                        enabled = brand.trim().isNotEmpty() && name.trim().isNotEmpty(),
                        modifier = Modifier.weight(1f).testTag("save_manual_btn")
                    ) {
                        Text("Kaydet", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==================== SHARED: PRODUCT DETAIL DIALOGUE AND ACTION SHEET ====================

@Composable
fun ProductDetailDialog(
    product: CosmeticProduct,
    currentTime: Long,
    onDismiss: () -> Unit,
    onToggleOpened: () -> Unit,
    onToggleMorning: () -> Unit,
    onToggleNight: () -> Unit,
    onDelete: () -> Unit
) {
    val expiryStatus = product.getExpirationStatus(currentTime)

    Dialog(onDismissRequest = { onDismiss() }) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f)
                .testTag("detail_dialog"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Category
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BadgeIndicator(
                        text = product.category.uppercase(Locale.getDefault()),
                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                        textColor = MaterialTheme.colorScheme.primary
                    )
                    IconButton(onClick = { onDismiss() }) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat")
                    }
                }

                // Info Headline
                Text(
                    text = product.brand,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
                Text(
                    text = product.name,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Divider()

                // Expiry countdown box
                Text("📅 Tazelik ve Kullanım Durumu", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = when (expiryStatus) {
                            is ExpirationStatus.Expired -> Color(0xFFFFEBEE)
                            is ExpirationStatus.ExpiringSoon -> Color(0xFFFFF8E1)
                            else -> Color(0xFFE8F5E9)
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                imageVector = when (expiryStatus) {
                                    is ExpirationStatus.Expired -> Icons.Default.Warning
                                    is ExpirationStatus.ExpiringSoon -> Icons.Default.Info
                                    else -> Icons.Default.Check
                                },
                                contentDescription = "Durum Simgesi",
                                tint = when (expiryStatus) {
                                    is ExpirationStatus.Expired -> Color(0xFFC62828)
                                    is ExpirationStatus.ExpiringSoon -> Color(0xFFF57F17)
                                    else -> Color(0xFF2E7D32)
                                }
                            )
                            Text(
                                text = when (expiryStatus) {
                                    is ExpirationStatus.NoLimit -> "Süre sınırı eklenmemiş."
                                    is ExpirationStatus.Expired -> "DİKKAT! Son Kullanma Tarihi Geçmiş!"
                                    is ExpirationStatus.ExpiringSoon -> "Yakında Süresi Dolacak"
                                    is ExpirationStatus.Safe -> "Taze ve Güvenli Kullanım"
                                },
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = when (expiryStatus) {
                                    is ExpirationStatus.Expired -> Color(0xFFC62828)
                                    is ExpirationStatus.ExpiringSoon -> Color(0xFFF57F17)
                                    else -> Color(0xFF2E7D32)
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = when (expiryStatus) {
                                is ExpirationStatus.NoLimit -> "Son kullanma veya açılış tarihi belirterek taze kalma takibini aktifleştirebilirsiniz."
                                is ExpirationStatus.Expired -> "Bu kozmetik ürünün ömrü doldu (${expiryStatus.daysAgo} gün geçmiş). Bakteri oluşumu vs. riskleri sebebiyle cildinize sürmekten kaçınmanız önerilir."
                                is ExpirationStatus.ExpiringSoon -> "Ürününüzün son kullanmasına veya koruyucu ömrüne son ${expiryStatus.daysLeft} gün kaldı. Lütfen hızlı tüketin!"
                                is ExpirationStatus.Safe -> "Ürününüz tamamen tazedir. Güvenle kullanabilirsiniz (Kalan süre: ${expiryStatus.daysLeft} gün)."
                            },
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                }

                // Open countdown controller buttons
                Button(
                    onClick = { onToggleOpened() },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (product.isOpened) Color(0xFF4A4A4A) else MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(
                        imageVector = if (product.isOpened) Icons.Default.Check else Icons.Default.PlayArrow,
                        contentDescription = "Durum Değiştir"
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (product.isOpened) "Kapağı kapat (Kullanımı Durdur)" else "Kapağı Aç, Kullanmaya Başla (PAO Sayacını Başlat)",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Divider()

                // Displaying Opening statistics and Expiry date
                if (product.expirationDate != null) {
                    Text(
                        text = "Son Kullanma Tarihi (SKT): " + SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(product.expirationDate)),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (product.isOpened && product.openingDate != null) {
                    Text(
                        text = "Ürünü Açtığınız Tarih: " + SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(product.openingDate)),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                if (product.paoMonths != null) {
                    Text(
                        text = "Önerilen Açıldıktan Sonra Ömür (PAO): ${product.paoMonths} Ay",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Divider()

                // Care Routines settings inside Detail Box
                Text("🌅/🌙 Günlük Bakım Rutini", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (product.isMorningRoutine) Color(0xFFFFF3CD) else Color(0xFFEEF1F6)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onToggleMorning() }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Gündüz Rutini", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Checkbox(checked = product.isMorningRoutine, onCheckedChange = { onToggleMorning() })
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (product.isNightRoutine) Color(0xFFEDE7F6) else Color(0xFFEEF1F6)
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onToggleNight() }
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Akşam Rutini", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Checkbox(checked = product.isNightRoutine, onCheckedChange = { onToggleNight() })
                        }
                    }
                }

                Divider()

                // Usage instructions (Kullanım Qaydaları)
                if (!product.usageInstructions.isNullOrEmpty()) {
                    Text("📖 Nasıl Kullanılır? (Kullanım Qaydaları)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
                    Text(text = product.usageInstructions, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                }

                // Safety precautions (Geniş güvenlik uyarısı)
                if (!product.warningNotes.isNullOrEmpty()) {
                    Text("⚠️ Bilmeniz Gereken Güvenlik Kuralları", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFFD62828))
                    Text(text = product.warningNotes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                }

                if (!product.notes.isNullOrEmpty()) {
                    Text("📝 Kişisel Notlarım", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Text(text = product.notes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Delete product button
                Button(
                    onClick = { onDelete() },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth().testTag("delete_product_btn")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Envanterden Sil")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ürünü Envanterden Tamamen Sil", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Text file downloading/sharing helper.
 * Triggers standard Android ACTION_SEND action which allows users on all devices (including emulator)
 * to save as files, download, copy or share coupon templates instantly.
 */
fun downloadOrShareCoupon(context: android.content.Context, title: String, content: String) {
    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(android.content.Intent.EXTRA_SUBJECT, title)
        putExtra(android.content.Intent.EXTRA_TEXT, content)
    }
    context.startActivity(android.content.Intent.createChooser(intent, "İndirim Kuponunu İndir / Paylaş"))
}

@Composable
fun DiscountsView(viewModel: CosmeticViewModel) {
    val context = LocalContext.current
    val dealAdvice by viewModel.dealAdvice.collectAsState()
    val isLoadingDeals by viewModel.isLoadingDeals.collectAsState()

    var searchQuery by remember { mutableStateOf("") }

    // Calculator inputs
    var basePriceStr by remember { mutableStateOf("1000") }
    var discount1Str by remember { mutableStateOf("50") }
    var discount2Str by remember { mutableStateOf("10") }
    var taxStr by remember { mutableStateOf("20") }

    val scrollState = rememberScrollState()

    // Prepopulated active deals in cosmetics
    val staticDeals = remember {
        listOf(
            Triple("Gratis Cilt Bakım Şenliği", "%50 Net İndirim + %10 Sepet İndirimi\nKupon Kodu: GRT50CLT\nGeçerlilik: 30 Haziran 2026", "GRT50CLT"),
            Triple("Sephora Gold Card Haftası", "Seçili Parfümlerde %40 Tasarruf\nKupon Kodu: SPHGLD40\nGeçerlilik: 15 Haziran 2026", "SPHGLD40"),
            Triple("Watsons Mega Güneş Kampanyası", "%30 İndirim + Güneş Koruyucularda Kargo Bedava\nKupon Kodu: GNS30WTS\nGeçerlilik: 10 Temmuz 2026", "GNS30WTS"),
            Triple("Rossmann Temiz İçerik İndirimi", "Seçili Isana ve Alterra Ürünlerinde 3 Al 2 Öde\nKupon Kodu: RSM3AL2\nGeçerlilik: 25 Haziran 2026", "RSM3AL2")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        
        // Tab Introdution Card
        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = "Kampanya",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
                Column {
                    Text(
                        text = "İndirim Takip & İndirme Aleti",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Aktif kampanyaları hesaplayın, AI ile kupon oluşturun ve anında indirin!",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Section 1: ACTIVE OFFERS & DOWNLOAD CODES
        Text(
            text = "🔥 Güncel Kozmetik Kampanyaları",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onBackground
        )

        staticDeals.forEach { deal ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(12.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = deal.first,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Box(
                            modifier = Modifier
                                .background(
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                    RoundedCornerShape(6.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = deal.third,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Text(
                        text = deal.second,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            val couponText = """
                                ========================================
                                      KOZMETİK İNDİRİM & KAMPANYA KARTI
                                ========================================
                                Kampanya: ${deal.first}
                                Detaylar: ${deal.second.replace("\n", " | ")}
                                Aktif İndirim Kodu: ${deal.third}
                                
                                Nasıl Kullanılır: Kozmetik mağazasında veya
                                online sepet adımında yukarıdaki indirim kodunu 
                                girerek indirimden yararlanabilirsiniz.
                                
                                Oluşturulma Tarihi: ${SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())}
                                Kozmetik Envanteri & İndirim Takip Aleti
                                ========================================
                            """.trimIndent()
                            downloadOrShareCoupon(context, deal.first, couponText)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer,
                            contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Kuponu İndir",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Kupon Kartını İndir / Kaydet", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        Divider(modifier = Modifier.padding(vertical = 8.dp))

        // Section 2: QUANTITATIVE KOZMETİK İNDİRİM HESAPLAYICI (INVOICE CREATOR & DOWNLOADER)
        Text(
            text = "🧮 Kozmetik İndirim ve Fiyat Hesaplayıcı",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onBackground
        )

        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Fiyat ve indirim oranlarını girerek net tasarrufu görün ve makbuz indirin.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = basePriceStr,
                        onValueChange = { basePriceStr = it.filter { char -> char.isDigit() || char == '.' } },
                        label = { Text("Fiyat (TL)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = discount1Str,
                        onValueChange = { discount1Str = it.filter { char -> char.isDigit() } },
                        label = { Text("İndirim (%)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = discount2Str,
                        onValueChange = { discount2Str = it.filter { char -> char.isDigit() } },
                        label = { Text("Ek İndirim (%)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = taxStr,
                        onValueChange = { taxStr = it.filter { char -> char.isDigit() } },
                        label = { Text("KDV / Vergi (%)") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Computation
                val basePrice = basePriceStr.toDoubleOrNull() ?: 0.0
                val d1 = (discount1Str.toDoubleOrNull() ?: 0.0) / 100.0
                val d2 = (discount2Str.toDoubleOrNull() ?: 0.0) / 100.0
                val tax = (taxStr.toDoubleOrNull() ?: 0.0) / 100.0

                val priceAfterFirst = basePrice * (1.0 - d1)
                val priceAfterSecond = priceAfterFirst * (1.0 - d2)
                val finalPrice = priceAfterSecond * (1.0 + tax)
                val totalSaved = basePrice - priceAfterSecond

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Orijinal Tutar:", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(String.format(Locale.US, "%.2f TL", basePrice), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Net Kazanç (Tasarruf):", fontSize = 13.sp, color = Color(0xFF2E7D32))
                            Text(String.format(Locale.US, "%.2f TL", totalSaved), fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 13.sp)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Ödenecek Son Tutar (KDV Dahil):", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Text(String.format(Locale.US, "%.2f TL", finalPrice), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, fontSize = 14.sp)
                        }
                    }
                }

                Button(
                    onClick = {
                        val fileHeader = """
                            ========================================
                                     KOZMETİK ALIŞVERİŞ HESAP FİŞİ
                            ========================================
                            Orijinal Ürün Fiyatı   : ${String.format(Locale.US, "%.2f", basePrice)} TL
                            Birincil İndirim Oranı : ${discount1Str}%
                            İkincil İndirim Oranı  : ${discount2Str}%
                            KDV Oranı              : ${taxStr}%
                            ----------------------------------------
                            TOPLAM NET TASARRUF    : ${String.format(Locale.US, "%.2f", totalSaved)} TL
                            ÖDENECEK SON TUTAR     : ${String.format(Locale.US, "%.2f", finalPrice)} TL
                            ----------------------------------------
                            Gereksiz harcamadan kaçındığınız ve
                            akıllı kozmetik alışverişi yaptığınız için
                            tebrikler! 🌸
                            
                            Tarih: ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())}
                            ========================================
                        """.trimIndent()
                        downloadOrShareCoupon(context, "Kozmetik_Hesap_Fisi", fileHeader)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Fişi İndir"
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Hesap Fişini İndir / Kaydet", fontWeight = FontWeight.Bold)
                }
            }
        }

        Divider(modifier = Modifier.padding(vertical = 8.dp))

        // Section 3: AI DISCOUNTS SCANNER (GEMINI AI ACTIVE DISCOUNTS)
        Text(
            text = "✨ Yapay Zeka ile Mağaza Kampanyası Arayıcı",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.onBackground
        )

        Card(
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Aramak istediğiniz mağazayı (örneğin 'Gratis', 'Watsons', 'L\'Oreal') yazın. Yapay zeka olası popüler indirimleri derleyecek ve indirebileceğiniz özel bir kupon kodu oluşturacak!",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Mağaza veya Marka Girin") },
                    placeholder = { Text("Örn: Gratis, Sephora, Rossmann") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Button(
                    onClick = {
                        if (searchQuery.isNotEmpty()) {
                            viewModel.queryActiveDiscounts(searchQuery)
                        }
                    },
                    enabled = searchQuery.isNotEmpty() && !isLoadingDeals,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    if (isLoadingDeals) {
                        CircularProgressIndicator(
                            color = MaterialTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Ara"
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Yapay Zeka ile Ara & Analiz Et", fontWeight = FontWeight.Bold)
                    }
                }

                // AI Result Portion
                dealAdvice?.let { result ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "🤖 AI Kampanya & Kupon Önerisi:",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 14.sp
                            )
                            Text(
                                text = result,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            Button(
                                onClick = {
                                    val formattedContent = """
                                        ========================================
                                                  AI BULUNAN KAMPANYA REHBERİ
                                        ========================================
                                        Arama Yapılan Hedef: $searchQuery
                                        
                                        $result
                                        
                                        Oluşturulma Tarihi: ${SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())}
                                        Cilt Sağlığınız ve Bütçeniz Bizim İçin Değerlidir!
                                        ========================================
                                    """.trimIndent()
                                    downloadOrShareCoupon(context, "AI_${searchQuery}_Kupon_Raporu", formattedContent)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Raporu İndir"
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Bulunan AI Kuponunu İndir / Kaydet", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}
